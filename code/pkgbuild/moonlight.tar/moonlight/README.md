# Moonlight Embedded

This folder is forked from the [Moonlight Embedded](https://github.com/moonlight-stream/moonlight-embedded) project and tuned for the thesis project.
